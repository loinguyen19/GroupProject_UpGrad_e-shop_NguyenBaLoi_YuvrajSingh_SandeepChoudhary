import ProductCategoryFilter from "../ProductCategoryFilter/ProductCategoryFilter";
import './Filters.css'
const Filters = () => {
  return (
    <div>
        <ProductCategoryFilter />
    </div>
  );
};

export default Filters;
